<template>
  <div class="hello">
      <navhead></navhead>
    <h3>关于我们</h3>
    <p>同步财经是全球区块链行业资讯内容、行情数据提供领跑者。作为全球最专业的区块链资讯、行情媒体平台，同步财经拥有最全面而优质的区块链数据资源，竭力为用户提供实时行情、专业K线、精准数据分析、精选全球资讯及行业观点交流等多元化便捷一站式服务。</p>
    <p>我们为区块链投资者和交易者提供专业的服务平台、与全面的区块链行业研究分析，始终领先市场一步。</p>
  </div>
</template>
<style scoped>
    .hello{
        color: #333;
        text-align: left;
    }
    .hello h3 {
        text-indent: 1rem;
        padding: 0 15px;
        font-size: 16px
    }
    .hello p {
        text-indent: 2rem;
        font-size: 14px;
         padding: 0 15px;
    }
</style>